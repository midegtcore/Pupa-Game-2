const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.TiledBg,
		C3.Plugins.Sprite,
		C3.Behaviors.EightDir,
		C3.Behaviors.scrollto,
		C3.Plugins.Text,
		C3.Plugins.Keyboard,
		C3.Plugins.System.Cnds.OnLayoutStart,
		C3.Plugins.Text.Acts.SetVisible,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.Keyboard.Cnds.OnKey,
		C3.Plugins.Sprite.Cnds.IsOverlapping,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.System.Cnds.Compare,
		C3.Plugins.System.Acts.Wait,
		C3.Plugins.Sprite.Acts.SetVisible,
		C3.Plugins.Sprite.Acts.SetPos
	];
};
self.C3_JsPropNameTable = [
	{Background: 0},
	{"8Direction": 0},
	{ScrollTo: 0},
	{Pupa: 0},
	{PiuPiu: 0},
	{Bed: 0},
	{Coffee: 0},
	{Sofa: 0},
	{Laptop: 0},
	{DialogueText: 0},
	{Easel: 0},
	{Keyboard: 0},
	{memories: 0}
];

self.InstanceType = {
	Background: class extends self.ITiledBackgroundInstance {},
	Pupa: class extends self.ISpriteInstance {},
	PiuPiu: class extends self.ISpriteInstance {},
	Bed: class extends self.ISpriteInstance {},
	Coffee: class extends self.ISpriteInstance {},
	Sofa: class extends self.ISpriteInstance {},
	Laptop: class extends self.ISpriteInstance {},
	DialogueText: class extends self.ITextInstance {},
	Easel: class extends self.ISpriteInstance {},
	Keyboard: class extends self.IInstance {}
}